#include "Logger.hpp"
#include <Windows.h>
#include <fstream>
#include <mutex>
#include <chrono>
#include <iomanip>
#include <sstream>
#include <thread>
#include <cstdio>

static std::mutex g_LogMutex;

static std::string Timestamp()
{
    SYSTEMTIME st{};
    GetLocalTime(&st);
    char buf[32]{};
    sprintf_s(buf, "%02u:%02u:%02u", st.wHour, st.wMinute, st.wSecond);
    return buf;
}

static std::string LogPath()
{
    char temp[MAX_PATH]{};
    DWORD n = GetTempPathA(MAX_PATH, temp);
    if (n == 0 || n >= MAX_PATH)
        return "ResurrectedOfflineBots.log";
    return std::string(temp) + "ResurrectedOfflineBots.log";
}

void Logger::Write(const char* level, const std::string& text)
{
    std::lock_guard<std::mutex> lock(g_LogMutex);
    const std::string line = "[" + Timestamp() + "] [" + level + "] " + text + "\r\n";
    OutputDebugStringA(line.c_str());
    std::ofstream out(LogPath(), std::ios::app | std::ios::binary);
    if (out) out.write(line.data(), static_cast<std::streamsize>(line.size()));
}

void Logger::Success(const std::string& text) { Write("+", text); }
void Logger::Error(const std::string& text)   { Write("-", text); }
void Logger::Debug(const std::string& text)   { Write("=", text); }
void Logger::Prompt(const std::string& text)  { Write("?", text); }
void Logger::InlineSuccess(const std::string& text) { Write("+", text); }
void Logger::Countdown(int seconds)
{
    for (int i = seconds; i >= 0; --i)
    {
        Write("+", "Closing in " + std::to_string(i) + " seconds");
        std::this_thread::sleep_for(std::chrono::seconds(1));
    }
}
