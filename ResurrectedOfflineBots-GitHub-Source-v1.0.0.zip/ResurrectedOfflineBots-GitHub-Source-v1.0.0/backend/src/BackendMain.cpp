#include <Windows.h>
#include "Game/Engine/Engine.hpp"
#include "Game/Features/Features.hpp"
#include "Utils/Logger/Logger.hpp"

static volatile LONG g_Running = 1;

static DWORD WINAPI BackendWorker(LPVOID)
{
    Logger::Success("ResurrectedOfflineBots backend loaded");
    Logger::Debug("Controls are owned by ResurrectedOfflineBots.exe: F1 Jason, F3 counselor");

    bool engineReady = false;

    while (InterlockedCompareExchange(&g_Running, 1, 1) != 0)
    {
        if (!engineReady)
        {
            engineReady = Engine::Initialize();
            if (!engineReady)
            {
                Logger::Debug("Engine not ready; retrying");
                Sleep(3000);
                continue;
            }

            Logger::Success("Resurrected engine ready");
        }

        if (func)
            func->TickAIOnly();

        Sleep(50);
    }

    return 0;
}

extern "C" __declspec(dllexport) DWORD WINAPI ROB_QueueJason(LPVOID)
{
    return (func && func->QueueFirstJasonSandbox()) ? 1u : 0u;
}

extern "C" __declspec(dllexport) DWORD WINAPI ROB_QueueCounselor(LPVOID)
{
    return QueueCounselorBotRequest() ? 1u : 0u;
}

extern "C" __declspec(dllexport) DWORD WINAPI ROB_Ping(LPVOID)
{
    return 0x524F424Fu; // "ROBO"
}

BOOL APIENTRY DllMain(HMODULE module, DWORD reason, LPVOID)
{
    if (reason == DLL_PROCESS_ATTACH)
    {
        DisableThreadLibraryCalls(module);
        HANDLE thread = CreateThread(nullptr, 0, BackendWorker, nullptr, 0, nullptr);
        if (thread) CloseHandle(thread);
    }
    else if (reason == DLL_PROCESS_DETACH)
    {
        InterlockedExchange(&g_Running, 0);
    }

    return TRUE;
}
