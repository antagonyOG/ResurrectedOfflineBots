// ResurrectedOfflineBots.exe
// Tiny x64 launcher/controller for the companion AI-only DLL.
package main

import (
    "fmt"
    "os"
    "path/filepath"
    "strings"
    "syscall"
    "time"
    "unsafe"
)

const (
    maxPath = 260
    th32csSnapProcess  = 0x00000002
    th32csSnapModule   = 0x00000008
    th32csSnapModule32 = 0x00000010
    processCreateThread     = 0x0002
    processVMOperation      = 0x0008
    processVMRead           = 0x0010
    processVMWrite          = 0x0020
    processQueryInformation = 0x0400
    memCommit  = 0x1000
    memReserve = 0x2000
    memRelease = 0x8000
    pageReadWrite = 0x04
    infinite = 0xFFFFFFFF
    dontResolveDLLReferences = 0x00000001
    vkF1 = 0x70
    vkF3 = 0x72
    vkEscape = 0x1B
)

var (
    kernel32 = syscall.NewLazyDLL("kernel32.dll")
    user32   = syscall.NewLazyDLL("user32.dll")

    pCreateToolhelp32Snapshot = kernel32.NewProc("CreateToolhelp32Snapshot")
    pProcess32FirstW          = kernel32.NewProc("Process32FirstW")
    pProcess32NextW           = kernel32.NewProc("Process32NextW")
    pModule32FirstW           = kernel32.NewProc("Module32FirstW")
    pModule32NextW            = kernel32.NewProc("Module32NextW")
    pOpenProcess              = kernel32.NewProc("OpenProcess")
    pCloseHandle              = kernel32.NewProc("CloseHandle")
    pVirtualAllocEx           = kernel32.NewProc("VirtualAllocEx")
    pVirtualFreeEx            = kernel32.NewProc("VirtualFreeEx")
    pWriteProcessMemory       = kernel32.NewProc("WriteProcessMemory")
    pCreateRemoteThread       = kernel32.NewProc("CreateRemoteThread")
    pWaitForSingleObject      = kernel32.NewProc("WaitForSingleObject")
    pGetExitCodeThread        = kernel32.NewProc("GetExitCodeThread")
    pGetModuleHandleW         = kernel32.NewProc("GetModuleHandleW")
    pLoadLibraryExW           = kernel32.NewProc("LoadLibraryExW")
    pFreeLibrary              = kernel32.NewProc("FreeLibrary")
    pGetProcAddress           = kernel32.NewProc("GetProcAddress")
    pGetAsyncKeyState         = user32.NewProc("GetAsyncKeyState")
)

type processEntry32 struct {
    Size              uint32
    CntUsage          uint32
    ProcessID         uint32
    DefaultHeapID     uintptr
    ModuleID          uint32
    CntThreads        uint32
    ParentProcessID   uint32
    PriClassBase      int32
    Flags             uint32
    ExeFile           [maxPath]uint16
}

type moduleEntry32 struct {
    Size          uint32
    ModuleID      uint32
    ProcessID     uint32
    GlblcntUsage  uint32
    ProccntUsage  uint32
    ModBaseAddr   uintptr
    ModBaseSize   uint32
    Module        uintptr
    SzModule      [256]uint16
    SzExePath     [maxPath]uint16
}

func closeHandle(h uintptr) {
    if h != 0 && h != ^uintptr(0) {
        pCloseHandle.Call(h)
    }
}

func findGameProcess() (uint32, string) {
    snap, _, _ := pCreateToolhelp32Snapshot.Call(th32csSnapProcess, 0)
    if snap == 0 || snap == ^uintptr(0) { return 0, "" }
    defer closeHandle(snap)

    var pe processEntry32
    pe.Size = uint32(unsafe.Sizeof(pe))
    ok, _, _ := pProcess32FirstW.Call(snap, uintptr(unsafe.Pointer(&pe)))
    for ok != 0 {
        name := syscall.UTF16ToString(pe.ExeFile[:])
        low := strings.ToLower(name)
        if low == "summercamp-win64-shipping.exe" ||
           low == "summercampshipping.exe" ||
           (strings.Contains(low, "summercamp-win64-shipping") && !strings.Contains(low, "offlinebots")) {
            return pe.ProcessID, name
        }
        ok, _, _ = pProcess32NextW.Call(snap, uintptr(unsafe.Pointer(&pe)))
    }
    return 0, ""
}

func moduleBase(pid uint32, wanted string) uintptr {
    snap, _, _ := pCreateToolhelp32Snapshot.Call(th32csSnapModule|th32csSnapModule32, uintptr(pid))
    if snap == 0 || snap == ^uintptr(0) { return 0 }
    defer closeHandle(snap)

    var me moduleEntry32
    me.Size = uint32(unsafe.Sizeof(me))
    ok, _, _ := pModule32FirstW.Call(snap, uintptr(unsafe.Pointer(&me)))
    for ok != 0 {
        name := syscall.UTF16ToString(me.SzModule[:])
        if strings.EqualFold(name, wanted) {
            return me.ModBaseAddr
        }
        ok, _, _ = pModule32NextW.Call(snap, uintptr(unsafe.Pointer(&me)))
    }
    return 0
}

func remoteKernelProc(pid uint32, proc *syscall.LazyProc) uintptr {
    localK32Name, _ := syscall.UTF16PtrFromString("kernel32.dll")
    localK32, _, _ := pGetModuleHandleW.Call(uintptr(unsafe.Pointer(localK32Name)))
    if localK32 == 0 { return 0 }
    if err := proc.Find(); err != nil { return 0 }
    localProc := proc.Addr()
    remoteK32 := moduleBase(pid, "kernel32.dll")
    if remoteK32 == 0 || localProc < localK32 { return 0 }
    return remoteK32 + (localProc - localK32)
}

func injectDLL(pid uint32, dllPath string) (uintptr, error) {
    baseName := filepath.Base(dllPath)
    if b := moduleBase(pid, baseName); b != 0 {
        return b, nil
    }

    access := uintptr(processCreateThread | processVMOperation | processVMRead | processVMWrite | processQueryInformation)
    ph, _, err := pOpenProcess.Call(access, 0, uintptr(pid))
    if ph == 0 { return 0, fmt.Errorf("OpenProcess: %v", err) }
    defer closeHandle(ph)

    p, err2 := syscall.UTF16FromString(dllPath)
    if err2 != nil { return 0, err2 }
    size := uintptr(len(p) * 2)

    remoteMem, _, err := pVirtualAllocEx.Call(ph, 0, size, memCommit|memReserve, pageReadWrite)
    if remoteMem == 0 { return 0, fmt.Errorf("VirtualAllocEx: %v", err) }
    defer pVirtualFreeEx.Call(ph, remoteMem, 0, memRelease)

    var written uintptr
    ok, _, err := pWriteProcessMemory.Call(ph, remoteMem, uintptr(unsafe.Pointer(&p[0])), size, uintptr(unsafe.Pointer(&written)))
    if ok == 0 || written != size { return 0, fmt.Errorf("WriteProcessMemory: %v", err) }

    remoteLoadLibrary := remoteKernelProc(pid, kernel32.NewProc("LoadLibraryW"))
    if remoteLoadLibrary == 0 { return 0, fmt.Errorf("could not resolve remote LoadLibraryW") }

    th, _, err := pCreateRemoteThread.Call(ph, 0, 0, remoteLoadLibrary, remoteMem, 0, 0)
    if th == 0 { return 0, fmt.Errorf("CreateRemoteThread(LoadLibraryW): %v", err) }
    pWaitForSingleObject.Call(th, infinite)
    closeHandle(th)

    // Rescan rather than trusting the 32-bit thread exit code as an x64 HMODULE.
    for i := 0; i < 50; i++ {
        if b := moduleBase(pid, baseName); b != 0 { return b, nil }
        time.Sleep(100 * time.Millisecond)
    }
    return 0, fmt.Errorf("DLL did not appear in target module list")
}

func exportRVA(dllPath, exportName string) (uintptr, error) {
    w, err := syscall.UTF16PtrFromString(dllPath)
    if err != nil { return 0, err }
    h, _, e := pLoadLibraryExW.Call(uintptr(unsafe.Pointer(w)), 0, dontResolveDLLReferences)
    if h == 0 { return 0, fmt.Errorf("LoadLibraryExW(local): %v", e) }
    defer pFreeLibrary.Call(h)

    nameBytes := append([]byte(exportName), 0)
    addr, _, e := pGetProcAddress.Call(h, uintptr(unsafe.Pointer(&nameBytes[0])))
    if addr == 0 { return 0, fmt.Errorf("GetProcAddress(%s): %v", exportName, e) }
    return addr - h, nil
}

func callRemoteExport(pid uint32, remoteDLL uintptr, dllPath, exportName string) (uint32, error) {
    rva, err := exportRVA(dllPath, exportName)
    if err != nil { return 0, err }

    access := uintptr(processCreateThread | processQueryInformation | processVMOperation | processVMRead)
    ph, _, e := pOpenProcess.Call(access, 0, uintptr(pid))
    if ph == 0 { return 0, fmt.Errorf("OpenProcess: %v", e) }
    defer closeHandle(ph)

    th, _, e := pCreateRemoteThread.Call(ph, 0, 0, remoteDLL+rva, 0, 0, 0)
    if th == 0 { return 0, fmt.Errorf("CreateRemoteThread(%s): %v", exportName, e) }
    defer closeHandle(th)
    pWaitForSingleObject.Call(th, infinite)

    var code uint32
    ok, _, e := pGetExitCodeThread.Call(th, uintptr(unsafe.Pointer(&code)))
    if ok == 0 { return 0, fmt.Errorf("GetExitCodeThread: %v", e) }
    return code, nil
}

func keyDown(vk uintptr) bool {
    r, _, _ := pGetAsyncKeyState.Call(vk)
    return (r & 0x8000) != 0
}

func main() {
    exePath, _ := os.Executable()
    root := filepath.Dir(exePath)
    dllPath, _ := filepath.Abs(filepath.Join(root, "ResurrectedOfflineBots.dll"))

    fmt.Println("Resurrected Offline Bots")
    fmt.Println("-------------------------")
    fmt.Println("Target: SummerCamp-Win64-Shipping.exe")
    fmt.Println("F1  = Spawn AI Jason (once per Sandbox session)")
    fmt.Println("F3  = Add counselor bot (repeat; current proven mode uses F1 Jason first)")
    fmt.Println("ESC = Close this launcher")
    fmt.Println("Backend log: %TEMP%\\ResurrectedOfflineBots.log")
    fmt.Println()

    if _, err := os.Stat(dllPath); err != nil {
        fmt.Printf("Missing companion DLL:\n%s\n\nBuild/copy ResurrectedOfflineBots.dll beside this EXE.\n", dllPath)
        fmt.Println("Press Enter to exit.")
        fmt.Scanln()
        return
    }

    var pid uint32
    var remoteDLL uintptr
    var f1Was, f3Was, escWas bool

    for {
        esc := keyDown(vkEscape)
        if esc && !escWas { return }
        escWas = esc

        currentPID, processName := findGameProcess()
        if currentPID == 0 {
            if pid != 0 { fmt.Println("Game closed. Waiting for it to start again...") }
            pid, remoteDLL = 0, 0
            time.Sleep(500 * time.Millisecond)
            continue
        }

        if currentPID != pid || remoteDLL == 0 {
            pid = currentPID
            fmt.Printf("Found %s (PID %d). Attaching AI backend...\n", processName, pid)
            b, err := injectDLL(pid, dllPath)
            if err != nil {
                fmt.Printf("Attach failed: %v\n", err)
                remoteDLL = 0
                time.Sleep(1500 * time.Millisecond)
                continue
            }
            remoteDLL = b
            fmt.Println("Attached. F1 = Jason, F3 = counselor.")
        }

        f1 := keyDown(vkF1)
        if f1 && !f1Was {
            code, err := callRemoteExport(pid, remoteDLL, dllPath, "ROB_QueueJason")
            if err != nil { fmt.Printf("F1 request failed: %v\n", err) } else if code != 0 { fmt.Println("F1: AI Jason queued.") } else { fmt.Println("F1: Jason request rejected/not ready (see backend log).") }
        }
        f1Was = f1

        f3 := keyDown(vkF3)
        if f3 && !f3Was {
            code, err := callRemoteExport(pid, remoteDLL, dllPath, "ROB_QueueCounselor")
            if err != nil { fmt.Printf("F3 request failed: %v\n", err) } else if code != 0 { fmt.Println("F3: counselor bot queued.") } else { fmt.Println("F3: counselor request rejected/not ready (F1 Jason first; max 6).") }
        }
        f3Was = f3

        time.Sleep(35 * time.Millisecond)
    }
}
